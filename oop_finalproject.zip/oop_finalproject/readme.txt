# Hospital Management System

The Hospital Management System is a C++ project designed to manage hospital-related information, including hospital details, patient records, doctors, appointments, medical reports, and more. The system utilizes Object-Oriented Programming (OOP) principles for modularity and maintainability.
Introduction
This project implements a Hospital Management System using C++. It allows for the management of hospitals, patients, doctors, appointments, and medical reports through a console-based interface.

## Features
Hospital Management
Patient Management
Doctor Management
Appointment Management
medical Report Management
