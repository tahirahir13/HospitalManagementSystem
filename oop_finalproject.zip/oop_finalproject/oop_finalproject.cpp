#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <windows.h>
using namespace std;
class hospital
{
private:
    string name;
    string address;
    string blood_group;

public:
    hospital() : name(""), address(""), blood_group("") {}
    void set_name(string Name)
    {
        name = Name;
    }
    void set_address(string Address)
    {
        address = Address;
    }
    void set_blood_group(string BGroup)
    {
        blood_group = BGroup;
    }
    string get_name()
    {
        return name;
    }
    string get_address()
    {
        return address;
    }
    string get_blood_group()
    {
        return blood_group;
    }
    void add_hospital(string Name, string Address, string BGroup)
    {
        set_name(Name);
        set_address(Address);
        set_blood_group(BGroup);
        ofstream hospital_file("hospital.txt", ios::app); // open file in append mode
        if (hospital_file.is_open())
        {
            hospital_file << "name= " << get_name() << endl;
            hospital_file << "address= " << get_address() << endl;
            hospital_file << "blood group= " << get_blood_group() << endl;
            hospital_file.close();
            cout << "hospital add successfully and saved to file /n";
        }
        else
        {
            cerr << "error= unable to open the file for writing./n";
        }
    }
    static void display_all_hospitals()
    {
        ifstream hospital_file("hospital.txt");
        if (hospital_file.is_open())
        {
            string line;
            while (getline(hospital_file, line))
            {
                cout << line << endl;
            }
            hospital_file.close();
        }
        else
        {
            cerr << "error= unable to open the file for reading./n";
        }
    }
};
class patient
{
private:
    string patient_name;
    int patient_age;
    string patient_gender;
    string patient_disease;

public:
    patient(string Name, int Age, string Gender, string Disease) : patient_name(Name), patient_age(Age), patient_gender(Gender), patient_disease(Disease) {}
    void display()
    {
        cout << "name= " << patient_name << "/nage= " << patient_age << "/ngender= " << patient_gender << "/ndisease= " << patient_disease << endl;
    }
    string get_patient_name()
    {
        return patient_name;
    }
    int get_patient_age()
    {
        return patient_age;
    }
    string get_patient_gender()
    {
        return patient_gender;
    }
    string get_patient_disease()
    {
        return patient_disease;
    }
    // function to add any new patient
    void add_patient(string Name, int Age, string Gender, string Disease)
    {
        patient_name = Name;
        patient_age = Age;
        patient_gender = Gender;
        patient_disease = Disease;
        ofstream patient_file("patient.txt", ios::app); // open file in append mode
        if (patient_file.is_open())
        {
            patient_file << "name= " << get_patient_name() << endl;
            patient_file << "age= " << get_patient_age() << endl;
            patient_file << "gender= " << get_patient_gender() << endl;
            patient_file << "disease= " << get_patient_disease() << endl;
            patient_file.close();
            cout << "patient add successfully and saved to file /n";
        }
        else
        {
            cerr << "error= unable to open file for writing./n";
        }
    }
    static void display_all_patients()
    {
        ifstream patient_file("patient.txt");
        if (patient_file.is_open())
        {
            string line;
            while (getline(patient_file, line))
            {
                cout << line << endl;
            }
            patient_file.close();
        }
        else
        {
            cerr << "error= unable to open the file for reading./n";
        }
    }
};
class patient_medical_record
{
public:
    int record_id;
    int patient_id;
    string patient_history;
    patient_medical_record(int rec_id, int pat_id, string pat_history) : record_id(rec_id), patient_id(pat_id), patient_history(pat_history) {}
    void display()
    {
        cout << "record id= " << record_id << "/npatient id= " << patient_id << "/npatient history= " << patient_history << endl;
    }
    int get_record_id()
    {
        return record_id;
    }
    int get_patient_id()
    {
        return patient_id;
    }
    string get_patient_history()
    {
        return patient_history;
    }
    void add_patient_medical_record(int rec_id, int pat_id, string pat_history)
    {
        record_id = rec_id;
        patient_id = pat_id;
        patient_history = pat_history;
        ofstream patient_medical_record_file("patient_medical_record.txt", ios::app);
        if (patient_medical_record_file.is_open())
        {
            patient_medical_record_file << "record id= " << get_record_id() << endl;
            patient_medical_record_file << "patient id= " << get_patient_id() << endl;
            patient_medical_record_file << "patient history= " << get_patient_history() << endl;
            patient_medical_record_file.close();
            cout << "patient_medical_record add successfully and saved to file /n";
        }
        else
        {
            cerr << "error= unable to open file for writing./n";
        }
    }
    static void display_all_patient_medical_record()
    {
        ifstream patient_medical_record_file("patient_medical_record.txt");
        if (patient_medical_record_file.is_open())
        {
            string line;
            while (getline(patient_medical_record_file, line))
            {
                cout << line << endl;
            }
            patient_medical_record_file.close();
        }
        else
        {
            cerr << "error= unable to open the file for reading./n";
        }
    }
};
class doctor
{
private:
    string doctor_name;
    int doctor_age;
    string doctor_specialization;
    int doctor_room_no;

public:
    doctor(string name, int age, string specialization, int room_no) : doctor_name(name), doctor_age(age), doctor_specialization(specialization), doctor_room_no(room_no) {}
    void display()
    {
        cout << "name= " << doctor_name << "/nage= " << doctor_age << "/nqualification= " << doctor_specialization << "/nroom number= " << doctor_room_no << endl;
    }
    string get_doctor_name()
    {
        return doctor_name;
    }
    int get_doctor_age()
    {
        return doctor_age;
    }
    string get_doctor_specialization()
    {
        return doctor_specialization;
    }
    int get_doctor_room_no()
    {
        return doctor_room_no;
    }
    void add_doctor(string name, int age, string specialization, int room_no)
    {
        doctor_name = name;
        doctor_age = age;
        doctor_specialization = specialization;
        doctor_room_no = room_no;
        ofstream doctor_file("doctor.txt", ios::app);
        if (doctor_file.is_open())
        {
            doctor_file << "name= " << get_doctor_name() << endl;
            doctor_file << "age= " << get_doctor_age() << endl;
            doctor_file << "specialization= " << get_doctor_specialization() << endl;
            doctor_file << "room number= " << get_doctor_room_no() << endl;
            doctor_file.close();
            cout << "doctor add successfully and saved to file /n";
        }
        else
        {
            cerr << "error= unable to open file for writing./n";
        }
    }
    static void display_all_doctors()
    {
        ifstream doctor_file("doctor.txt");
        if (doctor_file.is_open())
        {
            string line;
            while (getline(doctor_file, line))
            {
                cout << line << endl;
            }
            doctor_file.close();
        }
        else
        {
            cerr << "error= unable to open the file for reading./n";
        }
    }
};
class appointment
{
public:
    int appointment_id;
    int patient_id;
    string date;
    string time;
    int room_no;
    string attending_doctor_name;
    appointment(int app_id, int pat_id, string Date, string Time, int room, string doc_name) : appointment_id(app_id), patient_id(pat_id), date(Date), time(Time), room_no(room), attending_doctor_name(doc_name) {}
    void display()
    {
        cout << "appointment id= " << appointment_id << "/npatient id= " << patient_id << "/ndate= " << date << "/ntime= " << time << "/nroom number= " << room_no << "/n attendant= " << attending_doctor_name << endl;
    }
    int get_appointment_id()
    {
        return appointment_id;
    }
    int get_patient_id()
    {
        return patient_id;
    }
    string get_date()
    {
        return date;
    }
    string get_time()
    {
        return time;
    }
    int get_room_no()
    {
        return room_no;
    }
    string get_attending_doctor_name()
    {
        return attending_doctor_name;
    }
    void add_appointment(int app_id, int pat_id, string Date, string Time, int room, string doc_name)
    {
        appointment_id = app_id;
        patient_id = pat_id;
        date = Date;
        time = Time;
        room_no = room;
        attending_doctor_name = doc_name;
        ofstream appointment_file("appointment.txt", ios::app);
        if (appointment_file.is_open())
        {
            appointment_file << "appointment id= " << get_appointment_id() << endl;
            appointment_file << "patient id= " << get_patient_id() << endl;
            appointment_file << "date= " << get_date() << endl;
            appointment_file << "time= " << get_time() << endl;
            appointment_file << "room number= " << get_room_no() << endl;
            appointment_file << "attendant= " << get_attending_doctor_name() << endl;
            appointment_file.close();
            cout << "appointment add successfully and saved to file /n";
        }
        else
        {
            cerr << "error= unable to open file for writing./n";
        }
    }
    static void display_all_appointments()
    {
        ifstream appointment_file("appointment.txt");
        if (appointment_file.is_open())
        {
            string line;
            while (getline(appointment_file, line))
            {
                cout << line << endl;
            }
            appointment_file.close();
        }
        else
        {
            cerr << "error= unable to open the file for reading./n";
        }
    }
};
class medical_report
{
private:
    int report_id;
    int patient_id;
    string report_details;

public:
    medical_report(int rep_id, int pat_id, string rep_detail) : report_id(rep_id), patient_id(pat_id), report_details(rep_detail) {}
    void display()
    {
        cout << "report id= " << report_id << "/npatient id= " << patient_id << "/nreport details= " << report_details << endl;
    }
    int get_report_id()
    {
        return report_id;
    }
    int get_patient_id()
    {
        return patient_id;
    }
    string get_report_details()
    {
        return report_details;
    }
    void add_medical_report(int rep_id, int pat_id, string rep_detail)
    {
        report_id = rep_id;
        patient_id = pat_id;
        report_details = rep_detail;
        ofstream report_file("medical_report.txt", ios::app);
        if (report_file.is_open())
        {
            report_file << "report id= " << get_report_id() << endl;
            report_file << "patient id= " << get_patient_id() << endl;
            report_file << "report details= " << get_report_details() << endl;
            report_file.close();
            cout << "medical report add successfully and saved to file /n";
        }
        else
        {
            cerr << "error= unable to open file for writing./n";
        }
    }
    static void display_all_medical_reports()
    {
        ifstream report_file("medical_report.txt");
        if (report_file.is_open())
        {
            string line;
            while (getline(report_file, line))
            {
                cout << line << endl;
            }
            report_file.close();
        }
        else
        {
            cerr << "error= unable to open the file for reading./n";
        }
    }
};

// Function declarations
void hospitalMenu(hospital &myhospital);
void addHospital(hospital &myhospital);
void hospitalMenu(hospital &myhospital);
void addHospital(hospital &myhospital);
int main()
{
    int mainChoice;
    hospital myhospital;

    do
    {
        std::cout << "\n------ Hospital Management System ------\n";
        std::cout << "1. Hospital\n";
        std::cout << "2. Doctor (To be implemented)\n";
        std::cout << "3. Patient (To be implemented)\n";
        std::cout << "0. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> mainChoice;
        std::cin.ignore(); // Clear the newline character

        switch (mainChoice)
        {
        case 1:
            hospitalMenu(myhospital);
            break;
        case 2:
            // Doctor operations (to be implemented)
            std::cout << "Doctor operations will be implemented in the future.\n";
            break;
        case 3:
            // Patient operations (to be implemented)
            std::cout << "Patient operations will be implemented in the future.\n";
            break;
        case 0:
            std::cout << "Exiting the Hospital Management System.\n";
            break;
        default:
            std::cout << "Invalid choice. Please try again.\n";
        }

    } while (mainChoice != 0);

    return 0;
}

void hospitalMenu(hospital &myhospital)
{
    int hospitalChoice;

    do
    {
        std::cout << "\n------ Hospital Operations ------\n";
        std::cout << "1. Add Hospital\n";
        std::cout << "2. Display All Hospitals\n";
        std::cout << "0. Go Back\n";
        std::cout << "Enter your choice: ";
        std::cin >> hospitalChoice;
        std::cin.ignore(); // Clear the newline character

        switch (hospitalChoice)
        {
        case 1:
            addHospital(myhospital);
            break;
        case 2:
            std::cout << "\n----- Displaying All Hospitals -----\n";
            hospital::display_all_hospitals();
            break;
        case 0:
            std::cout << "Going back to the main menu.\n";
            break;
        default:
            std::cout << "Invalid choice. Please try again.\n";
        }

    } while (hospitalChoice != 0);
}

void addHospital(hospital &myhospital)
{
    std::string hospitalName, hospitalAddress, bloodGroup;
    std::cout << "Enter hospital name: ";
    getline(std::cin, hospitalName);
    std::cout << "Enter hospital address: ";
    getline(std::cin, hospitalAddress);
    std::cout << "Enter blood group: ";
    getline(std::cin, bloodGroup);
    myhospital.add_hospital(hospitalName, hospitalAddress, bloodGroup);
    std::cout << "Hospital added successfully.\n";
}